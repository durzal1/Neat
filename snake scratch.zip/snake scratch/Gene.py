class Gene():
    # type = input, hidden, or output or bias
    #          1        2        3        4
    def __init__(self, type, innovation_number, value, layer):
        self.type = type
        self.innovation_number = innovation_number
        self.value = value
        self.layer = layer
        self.sigmoid_value = 0
        self.done = False

