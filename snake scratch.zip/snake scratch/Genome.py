from Gene import *
from System import *
from ConnectionGene import *
from HiddenNode import *
import math
import random
import copy
import numpy as np
import math
PROBABILITY_MUTATE_LINK = 0.3 #.05 in smaller pop and 0.3 for large pop
PROBABILITY_BIAS_MUTATE_LINK = 0.4 #.05 in smaller pop and 0.4 for large pop
PROBABILITY_MUTATE_NODE = 0.03
PROBABILITY_MUTATE_WEIGHTS = 0.8
PROBABILITY_MUTATE_WEIGHT_SHIFT = 0.9
PROBABILITY_MUTATE_WEIGHT_RANDOM= 0.1
PROBABILITY_MUTATE_TOGGLE_LINK = 0.0
WEIGHT_SHIFT_STRENGTH = 1 #todo play around with mutation


#creates brand new genome
class Genome():
    def __init__(self, inputs, outputs, system):
        self.system = system
        self.inputs = inputs
        self.outputs = outputs
        self.place = 0
        self.nodes = []
        self.connections = []
        self.layer = 1
        self.node_num = 1
        self.age = 0
        self.inno_number = 0
        self.encode()
        self.mutate()
        self.best_connections = copy.deepcopy(self.connections)
        for i in range(len(self.best_connections)):
            self.best_connections[i] = 0
        self.excess_genes = []
        self.excess_genes_innos = []
        self.disjoint_genes = []
        self.disjoint_genes_innos = []
        self.similar_connections = []
        self.fitness = 0
        self.right = 0
        self.amount_reproduce = 0
        self.precent = 0
        # self.check_connections()

    def check_connections(self):
        # fix multiple same innos in one genome
        run = 0
        while run <= len(self.connections):
            run += 1
            try:
                for i in range(len(self.connections)):
                    for a in range(len(self.connections)):
                        if a != i:
                            if self.connections[i].innovation_number == self.connections[a].innovation_number:
                                self.connections.pop(a)
                                run = 0
            except Exception:
                pass
        #sort innovation numbers
        self.best_connections = copy.deepcopy(self.connections)
        for i in range(len(self.best_connections)):
            self.best_connections[i] = 0
        c_list = [] #check list
        innos_list = []
        for connection in self.connections:
            innos_list.append(connection.innovation_number)
        innos_list.sort()
        for connection in self.connections:
            for i in range(len(innos_list)):
                if connection.innovation_number == innos_list[i]:
                    connection.place = i
                    innos_list[i] = 99999999999999999999999999999999 #make sure it cant be used again
                    c_list.append([connection.innovation_number, i])
        for i in range(len(c_list)):
            for connection in self.connections:
                if connection.innovation_number == c_list[i][0]:
                    connection.place = c_list[i][1]
                    self.best_connections[connection.place] = connection
    def more_connections_than_node(self):
        # if connection has a node that isnt in self.nodes
        for connection in self.connections:
            gene_to = connection.gene_to
            gene_from = connection.gene_from
            if len(self.nodes) < gene_from:
                self.inno_number += 1
                self.node_num += 1
                self.nodes.append(Gene(2, self.inno_number, 0, self.layer))
                if self.node_num > self.inputs:
                    self.node_num = 0
                    self.layer += 1
            if len(self.nodes) < gene_to:
                self.inno_number += 1
                self.node_num += 1
                self.nodes.append(Gene(2, self.inno_number, 0, self.layer))
                if self.node_num > self.inputs:
                    self.node_num = 0
                    self.layer += 1
    def random_val(self):
        val = random.uniform(-1,1)
        return val
    def encode(self):

        for i in range(self.inputs):
            self.inno_number += 1
            #change weight from none to the value of the input
            self.nodes.append(Gene(1,self.inno_number,0, self.layer))
        for i in range(self.outputs):
            self.inno_number += 1
            self.nodes.append(Gene(3,self.inno_number,0, self.layer))
        for i in range(self.inputs):
            for a in range(self.outputs):
                gene_from = i + 1
                gene_to = self.inputs + a + 1
                weight = self.random_val()
                innovation_number = self.system.set_inno_number(gene_from, gene_to)
                self.connections.append(ConnectionGene(innovation_number, gene_from, gene_to, True, weight, gene_to ))
        # adds bias
        self.inno_number += 1
        self.nodes.append(Gene(4, self.inno_number, 1, self.layer))
        self.layer += 1
        #connection between bias and output
        for i in range(self.outputs):
            gene_from = self.outputs + self.inputs + 1
            gene_to = self.inputs + i + 1
            weight = self.random_val()
            innovation_number = self.system.set_inno_number(gene_from, gene_to)
            self.connections.append(ConnectionGene(innovation_number, gene_from, gene_to, True, weight, gene_to))

    def mutate(self):
        def bias_mutate_link():
            for i in range(len(self.nodes)):
                if self.nodes[i].type == 2:
                    gene_from = self.nodes[self.inputs+self.outputs ].innovation_number
                    gene_to = self.nodes[i].innovation_number
                    works = True
                    for q in range(len(self.connections)):
                        innovation_number = self.system.set_inno_number(gene_from, gene_to)
                        t = self.connections[q].innovation_number
                        if innovation_number == t:
                            works = False
                    if works:
                        innovation_number = self.system.set_inno_number(gene_from, gene_to)
                        weight = self.random_val()
                        self.connections.append(ConnectionGene(innovation_number, gene_from, gene_to, True, weight, 8))
                        return None



        def mutate_link():
            if len(self.nodes) > self.inputs + self.outputs + 1:
                for node1 in (self.nodes):
                    # if it san output ir bias go next
                    if node1.type == 3 or node1.type == 4:
                        continue
                    for node2 in self.nodes:
                        # if they're the same node or in the same layer go next
                        if node2 == node1 or node1.layer == node2.layer:
                            continue
                        connection_name = f"{node1.innovation_number}_{node2.innovation_number}"
                        for connection in self.connections:
                            gene_to = connection.gene_to
                            gene_from = connection.gene_from
                            name1 = f"{gene_to}_{gene_from}"
                            name2 = f"{gene_from}_{gene_to}"
                            # if connection has not already been made
                            if connection_name != name1 and connection_name != name2:
                                innovation_number = self.system.set_inno_number(gene_from, gene_to)
                                weight = self.random_val()
                                self.connections.append(
                                    ConnectionGene(innovation_number, node1.innovation_number, node2.innovation_number,True, weight, 8))
                                return None


        def mutate_node():
            len1 = len(self.connections)
            get_con = False
            n = 0
            #gets a connection that is that does not have the bias as its gene_from
            while not(get_con):
                n += 1
                ran_num = random.randint(0, len1 - 1)  # gets random connection
                if n> len1 :
                    self.connections[ran_num].is_enabled = True
                con = self.connections[ran_num]
                active = con.is_enabled
                gene_from = con.gene_from
                gene_to = con.gene_to
                if active and self.nodes[gene_from -1].type != 4:
                    con.is_enabled = False
                    self.inno_number += 1
                    self.nodes.append(Gene(2, self.inno_number, 0, self.layer))
                    og_weight = con.weight
                    gene_from1 = gene_from
                    gene_to1 = self.inno_number
                    gene_from2 = gene_to1
                    gene_to2 = con.gene_to
                    innovation_number = self.system.set_inno_number(gene_from1, gene_to1)
                    self.connections.append(ConnectionGene(innovation_number, gene_from1, gene_to1, True, 1, 0))
                    innovation_number1 = self.system.set_inno_number(gene_from2, gene_to2)
                    self.connections.append(
                        ConnectionGene(innovation_number1, gene_from2, gene_to2, True, og_weight, 0))
                    self.node_num += 1
                    if self.node_num > self.inputs:
                        self.node_num = 0
                        self.layer += 1
                    self.nodes[gene_from - 1].done = True
                    get_con = True
                    return None
                else:
                    continue






        def mutate_weight_shift():
            len1 = len(self.connections)
            ran_num = random.randint(0, len1 - 1)
            for i in range(len1):
                #gets age of gene_from to get weight_shift_stregth
                #older the gene the less it should be changed because theoretically it should be better
                age = self.age
                val = 70 * (0.96) ** age
                WEIGHT_SHIFT_STRENGTH = val / 100
                # changes the value of a weight by adding it to a random val
                if i == ran_num:
                    mult_num = random.uniform(-2, 2)
                    num = (mult_num * WEIGHT_SHIFT_STRENGTH)
                    add_ = self.connections[i].weight + num
                    if add_ >= 2 or add_ <= -2:
                        pass
                    else:
                        self.connections[i].weight = add_
        def mutate_weight_random():
            len1 = len(self.connections)
            ran_num = random.randint(0, len1 - 1)
            for i in range(len1):
                # changes the value completely between -2, 2
                if i == ran_num:
                    new_num = self.random_val()
                    self.connections[i].weight = new_num
        def toggle_link():
            len1 = len(self.connections)
            ran_num = random.randint(0, len1)
            for i in range(len1):
                on = self.connections[i].is_enabled
                if on:
                    self.connections[i].is_enabled = False
                else:
                    self.connections[i].is_enabled = True
        # does mutations
        num1 = random.random()
        if PROBABILITY_MUTATE_LINK >= num1:
            mutate_link()
        num2 = random.random()
        if PROBABILITY_MUTATE_NODE >= num2:
            mutate_node()
        num5 = random.random()
        if PROBABILITY_BIAS_MUTATE_LINK >= num5:
            bias_mutate_link()
        num4 = random.random()
        if PROBABILITY_MUTATE_WEIGHTS >= num4:
            num3 = random.random()
            if PROBABILITY_MUTATE_WEIGHT_SHIFT >= num3:
                mutate_weight_shift()
            num4 = random.random()
            if PROBABILITY_MUTATE_WEIGHT_RANDOM >= num4:
                mutate_weight_random()
        num6 = random.random()
        if PROBABILITY_MUTATE_TOGGLE_LINK >= num6:
            toggle_link()
        self.check_connections()

    def test_genome(self, inputs, outputs):
        self.more_connections_than_node()
        self.right = 0
        self.fitness = 4
        real_outputs = []
        for i in range(len(inputs)):
            output = self.calculate(inputs[i])
            for a in range(len(output)):
                val = output[a]
                if val < 0.5:
                    real_output = 0
                elif output[a] >=0.5:
                    real_output = 1
                real_outputs.append(real_output)
                real_outputs.append(val)
                if real_output == outputs[i]:
                    v = (val - outputs[i]) ** 2
                    self.fitness -= v
                else:
                    v = (val - outputs[i] ) ** 2
                    self.fitness -= v
        #     print(val)
        # print(self.right)
        #this is where ill actually test the genome and get its fitness
    def calculate(self, inputs):
        # self.check_connections()
        #reset all previous values
        for node in self.nodes:
            node.value = 0
            # set values of inputs
            for i in range(len(self.nodes)):
                if self.nodes[i].type == 1:
                    self.nodes[i].value = inputs[i]

                if self.nodes[i].type == 4:
                    self.nodes[i].value = 1
        #define simgoid function
        def sigmoid(x):
            try:
                sigmoid = 1 / (1 + np.exp(-x))   # try doing the modifed one in pdf
            except Exception:
                print("s")
            return sigmoid

        #sets values of hidden nodes
        for connection in self.best_connections:
            is_enabled = connection.is_enabled
            if is_enabled:
                gene_from = connection.gene_from
                gene_to = connection.gene_to
                try:
                    if self.nodes[gene_to - 1].type != 3:
                        for i in range(len(self.nodes)):
                            if i == gene_from - 1:
                                # if its an input it sigmoides the value
                                if self.nodes[i].type == 1:
                                    value_gene = (self.nodes[i].value)
                                else:
                                    value_gene = sigmoid(self.nodes[i].value)
                                break
                        weight = connection.weight
                        val = value_gene * weight
                        for i in range(len(self.nodes)):
                            if i == gene_to - 1:
                                self.nodes[i].value += val
                except Exception:
                    print(len(self.nodes), gene_to)

        for node in self.nodes:
            if node.type == 2:
                node.sigmoid_value = sigmoid(node.value)
            ###node value is the unsigmoided vaule
        #checks what last layer is
        layers = []
        for i in range(len(self.nodes)):
            layers.append(self.nodes[i].layer)
        max_layer = max(layers)
        #gets output by adding all of last layer nodes' values
        new_val = []
        for i in range(len(self.nodes)):
            if self.nodes[i].layer == max_layer:
                innovation_node = self.nodes[i].innovation_number
                for connection in self.best_connections:
                    active = connection.is_enabled
                    if active:
                        gene_from = connection.gene_from
                        gene_to = connection.gene_to
                        weight = connection.weight
                        #get nodes list
                        out_nodes = []
                        for node in self.nodes:
                            if node.type == 3:
                                out_nodes.append(node.innovation_number)
                        n = out_nodes[-self.outputs:]
                        #if from is the node and to nodet is going to an output node
                        for a in range(len(n)):
                            val = sigmoid(self.nodes[gene_from - 1].value) * weight
                            if gene_from == innovation_node and gene_to == n[a]:
                                self.nodes[n[a] - 1].value += val
                    else:
                        out_nodes = []
                        for node in self.nodes:
                            if node.type == 3:
                                out_nodes.append(node.innovation_number)
                        n = out_nodes[-self.outputs:]
        #resets value of output
        for node in self.nodes:
            if node.type == 3:
                node.value = 0
        #adds the bias and inputs
        for connection in self.best_connections:
            from_con = connection.gene_from
            gene_to = connection.gene_to
            weight = connection.weight
            active = connection.is_enabled
            # print(len(self.nodes), from_con, gene_to)
            if self.nodes[from_con - 1].type == 4 and self.nodes[gene_to - 1].type == 3:
                val = self.nodes[from_con - 1].value * weight
                self.nodes[gene_to - 1].value += val
            if self.nodes[from_con - 1].type == 1 and self.nodes[gene_to - 1].type == 3:
                if active:
                    val = self.nodes[from_con - 1].value * weight
                    self.nodes[gene_to - 1].value += val

        out_nodes = []
        for i in range(len(self.nodes)):
            if self.nodes[i].type ==3:
                out_nodes.append(i)
        outputs_ = []
        for i in range(len(self.nodes)):
            if i in out_nodes:
                val = sigmoid(self.nodes[i].value)
                self.nodes[i].sigmoid_value = val
                outputs_.append(val)
        inputs = inputs
        return outputs_



