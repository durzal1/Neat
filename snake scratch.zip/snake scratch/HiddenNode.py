from Genome import *
from Gene import *
from ConnectionGene import *
#didnt end up using this
class HiddenNode(Gene):
    def __init__(self):
        pass

